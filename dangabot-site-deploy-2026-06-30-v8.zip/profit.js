const byId = (id) => document.getElementById(id);
const profitFields = ["project-price", "planned-hours", "revision-hours", "direct-cost", "target-hourly"];
const wonFormat = new Intl.NumberFormat("ko-KR", { style: "currency", currency: "KRW", maximumFractionDigits: 0 });

function numberValue(id) {
  return Math.max(0, Number(byId(id).value) || 0);
}

function roundUp(value, unit = 1000) {
  return Math.ceil(value / unit) * unit;
}

function calculateProfit() {
  const price = numberValue("project-price");
  const plannedHours = numberValue("planned-hours");
  const revisionHours = numberValue("revision-hours");
  const directCost = numberValue("direct-cost");
  const targetHourly = numberValue("target-hourly");
  const totalHours = plannedHours + revisionHours;
  const netRevenue = price - directCost;
  const effectiveHourly = totalHours > 0 ? roundUp(Math.max(0, netRevenue) / totalHours) : 0;
  const requiredPrice = roundUp(totalHours * targetHourly + directCost, 10000);
  const gap = requiredPrice - price;

  byId("effective-hourly").textContent = wonFormat.format(effectiveHourly);
  byId("total-hours").textContent = `${Math.round(totalHours * 10) / 10}시간`;
  byId("net-revenue").textContent = wonFormat.format(netRevenue);
  byId("required-price").textContent = wonFormat.format(requiredPrice);
  byId("price-gap").textContent = gap > 0 ? `${wonFormat.format(gap)} 부족` : gap < 0 ? `${wonFormat.format(Math.abs(gap))} 여유` : "목표와 동일";

  if (totalHours === 0) {
    byId("profit-status").textContent = "작업시간을 입력하세요.";
    byId("profit-advice").textContent = "예상 작업시간이 있어야 실제 단가를 계산할 수 있습니다.";
  } else if (gap > 0) {
    byId("profit-status").textContent = "수정 범위를 먼저 잠그세요.";
    byId("profit-advice").textContent = `목표 단가를 지키려면 견적을 ${wonFormat.format(requiredPrice)} 이상으로 조정하세요.`;
  } else {
    byId("profit-status").textContent = "목표 단가를 지키고 있습니다.";
    byId("profit-advice").textContent = "계약서에 작업 범위와 수정 횟수를 명확히 남기세요.";
  }

  return { price, totalHours, directCost, netRevenue, effectiveHourly, requiredPrice, gap };
}

function showProfitToast(message) {
  const toast = byId("toast");
  toast.textContent = message;
  toast.classList.add("show");
  window.setTimeout(() => toast.classList.remove("show"), 2200);
}

profitFields.forEach((id) => byId(id).addEventListener("input", calculateProfit));

byId("copy-profit").addEventListener("click", async () => {
  const result = calculateProfit();
  const gapText = result.gap > 0 ? `${wonFormat.format(result.gap)} 부족` : result.gap < 0 ? `${wonFormat.format(Math.abs(result.gap))} 여유` : "목표와 동일";
  const text = `단가봇 프로젝트 수익 계산\n실제 시간당 수익: ${wonFormat.format(result.effectiveHourly)}\n총 투입시간: ${result.totalHours}시간\n비용 제외 수익: ${wonFormat.format(result.netRevenue)}\n목표를 지키는 견적: ${wonFormat.format(result.requiredPrice)}\n현재 견적과 차이: ${gapText}`;
  try {
    await navigator.clipboard.writeText(text);
    showProfitToast("계산 결과를 복사했습니다.");
  } catch {
    showProfitToast("복사할 수 없습니다. 브라우저 권한을 확인해 주세요.");
  }
});

byId("year").textContent = new Date().getFullYear();
calculateProfit();
