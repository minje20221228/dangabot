const $ = (id) => document.getElementById(id);
const fields = ["monthly-goal", "work-days", "hours-day", "billable-rate", "buffer-rate", "project-hours"];
const won = new Intl.NumberFormat("ko-KR", { style: "currency", currency: "KRW", maximumFractionDigits: 0 });

function value(id) {
  return Math.max(0, Number($(id).value) || 0);
}

function roundTo(value, unit = 1000) {
  return Math.ceil(value / unit) * unit;
}

function calculate() {
  const monthlyGoal = value("monthly-goal");
  const workDays = value("work-days");
  const hoursDay = value("hours-day");
  const billableRate = Math.min(value("billable-rate"), 100) / 100;
  const bufferRate = value("buffer-rate") / 100;
  const projectHours = value("project-hours");

  const billableHours = workDays * hoursDay * billableRate;
  const revenueGoal = monthlyGoal * (1 + bufferRate);
  const hourly = billableHours > 0 ? roundTo(revenueGoal / billableHours) : 0;
  const daily = roundTo(hourly * hoursDay, 10000);
  const project = roundTo(hourly * projectHours, 10000);

  $("hourly-rate").textContent = won.format(hourly);
  $("daily-rate").textContent = won.format(daily);
  $("project-rate").textContent = won.format(project);
  $("billable-hours").textContent = `${Math.round(billableHours * 10) / 10}시간`;
  $("revenue-goal").textContent = won.format(revenueGoal);
  $("proposal-line").textContent = `“본 프로젝트의 제안 금액은 ${project.toLocaleString("ko-KR")}원입니다.”`;

  return { hourly, daily, project, billableHours, revenueGoal };
}

function showToast(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.add("show");
  window.setTimeout(() => toast.classList.remove("show"), 2200);
}

fields.forEach((id) => $(id).addEventListener("input", calculate));

$("copy-result").addEventListener("click", async () => {
  const result = calculate();
  const text = `단가봇 계산 결과\n시간 단가: ${won.format(result.hourly)}\n하루 단가: ${won.format(result.daily)}\n프로젝트 단가: ${won.format(result.project)}\n월 청구 가능 시간: ${Math.round(result.billableHours * 10) / 10}시간\n필요 월매출: ${won.format(result.revenueGoal)}`;
  try {
    await navigator.clipboard.writeText(text);
    showToast("계산 결과를 복사했습니다.");
  } catch {
    showToast("복사할 수 없습니다. 브라우저 권한을 확인해 주세요.");
  }
});

$("buy-button").addEventListener("click", (event) => {
  const url = event.currentTarget.dataset.checkoutUrl;
  if (!url || url.includes("YOUR_")) {
    event.preventDefault();
    showToast("운영자가 결제 링크를 연결하는 중입니다.");
    return;
  }
  event.currentTarget.href = url;
  event.currentTarget.target = "_blank";
  event.currentTarget.rel = "noopener";
});

$("year").textContent = new Date().getFullYear();
calculate();
